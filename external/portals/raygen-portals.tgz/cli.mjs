#!/usr/bin/env node
import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);

// src/cli.js
import { parseArgs } from "node:util";

// src/client.js
import { request } from "node:http";
function callPortal(input) {
  return new Promise((resolve, reject) => {
    const req = request(
      {
        socketPath: process.env.RAYGEN_PORTAL_SOCKET ?? "/run/raygen-portals/control.sock",
        path: "/control",
        method: "POST",
        headers: { "content-type": "application/json" }
      },
      (res) => {
        let body = "";
        res.on("data", (chunk) => {
          body += chunk;
        });
        res.on("end", () => {
          try {
            const result = JSON.parse(body);
            if (res.statusCode !== 200)
              reject(new Error(result.error ?? "Portal operation failed"));
            else resolve(result);
          } catch (error) {
            reject(error);
          }
        });
      }
    );
    req.setTimeout(
      45e3,
      () => req.destroy(
        new Error("Portal operation timed out; check status before retrying")
      )
    );
    req.on("error", reject);
    req.end(JSON.stringify(input));
  });
}

// src/cli.js
try {
  const { values, positionals } = parseArgs({
    allowPositionals: true,
    options: {
      name: { type: "string" },
      cwd: { type: "string" },
      command: { type: "string" },
      port: { type: "string" },
      thread: { type: "string" },
      help: { type: "boolean" }
    }
  });
  if (values.help || positionals.length !== 1) {
    console.log(
      "Usage: raygen-portal <start|expose|list|status|logs|restart|stop|login-url> [--name NAME] [--cwd DIR --command COMMAND] [--port PORT] [--thread THREAD]\nThread defaults to AMP_THREAD_ID. Login URLs are sensitive and expire after 60 seconds."
    );
    process.exitCode = values.help ? 0 : 1;
  } else {
    const options = { ...values };
    delete options.help;
    const result = await callPortal({
      ...options,
      ...values.port !== void 0 && { port: Number(values.port) },
      action: positionals[0],
      thread: values.thread ?? process.env.AMP_THREAD_ID
    });
    console.log(JSON.stringify(result, null, 2));
    if (result.ready === false) process.exitCode = 1;
  }
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
