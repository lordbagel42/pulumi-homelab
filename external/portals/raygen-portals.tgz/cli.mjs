#!/usr/bin/env node
import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);

// src/cli.js
import { parseArgs } from "node:util";
import { createInterface } from "node:readline/promises";
import { Writable } from "node:stream";

// src/client.js
import { request } from "node:http";
function callPortal(input) {
  return new Promise((resolve, reject) => {
    const req = request(
      {
        socketPath: process.env.RAYGEN_PORTAL_SOCKET ?? "/run/raygen-portals/control.sock",
        path: "/control",
        method: "POST",
        headers: { "content-type": "application/json" }
      },
      (res) => {
        let body = "";
        res.on("data", (chunk) => {
          body += chunk;
        });
        res.on("end", () => {
          try {
            const result = JSON.parse(body);
            if (res.statusCode !== 200)
              reject(new Error(result.error ?? "Portal operation failed"));
            else resolve(result);
          } catch (error) {
            reject(error);
          }
        });
      }
    );
    req.setTimeout(
      45e3,
      () => req.destroy(
        new Error("Portal operation timed out; check status before retrying")
      )
    );
    req.on("error", reject);
    req.end(JSON.stringify(input));
  });
}

// src/cli.js
try {
  const { values, positionals } = parseArgs({
    allowPositionals: true,
    options: {
      name: { type: "string" },
      cwd: { type: "string" },
      command: { type: "string" },
      port: { type: "string" },
      thread: { type: "string" },
      "pin-stdin": { type: "boolean" },
      help: { type: "boolean" }
    }
  });
  if (values.help || positionals.length !== 1) {
    console.log(
      "Usage: raygen-portal <start|expose|list|status|logs|restart|stop|login-url|set-pin> [--name NAME] [--cwd DIR --command COMMAND] [--port PORT] [--thread THREAD] [--pin-stdin]\nset-pin changes the shared PIN using a hidden terminal prompt. --pin-stdin reads a PIN from stdin (also supported by start/expose). Thread defaults to AMP_THREAD_ID. Login URLs are sensitive and expire after 60 seconds."
    );
    process.exitCode = values.help ? 0 : 1;
  } else {
    const options = { ...values };
    delete options.help;
    delete options["pin-stdin"];
    let pin;
    if (values["pin-stdin"]) {
      let input = "";
      for await (const chunk of process.stdin) {
        input += chunk;
        if (input.length > 64) throw new Error("PIN input too long");
      }
      pin = input.trim();
    } else if (positionals[0] === "set-pin") {
      if (!process.stdin.isTTY)
        throw new Error("Use --pin-stdin or run set-pin in a terminal");
      let muted = false;
      const output = new Writable({
        write(chunk, _encoding, done) {
          if (!muted) process.stdout.write(chunk);
          done();
        }
      });
      const terminal = createInterface({
        input: process.stdin,
        output,
        terminal: true
      });
      terminal.on("SIGINT", () => {
        terminal.close();
        process.exit(130);
      });
      try {
        const answer = terminal.question("New shared PIN (6\u201312 digits): ");
        muted = true;
        pin = await answer;
      } finally {
        terminal.close();
        process.stdout.write("\n");
      }
    }
    const result = await callPortal({
      ...options,
      ...pin !== void 0 && { pin },
      ...values.port !== void 0 && { port: Number(values.port) },
      action: positionals[0],
      thread: values.thread || process.env.AMP_THREAD_ID || (positionals[0] === "set-pin" ? "T-00000000-0000-0000-0000-000000000000" : void 0)
    });
    console.log(JSON.stringify(result, null, 2));
    if (result.ready === false) process.exitCode = 1;
  }
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
