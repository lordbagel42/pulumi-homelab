// src/client.js
import { request } from "node:http";
function callPortal(input) {
  return new Promise((resolve, reject) => {
    const req = request(
      {
        socketPath: process.env.RAYGEN_PORTAL_SOCKET ?? "/run/raygen-portals/control.sock",
        path: "/control",
        method: "POST",
        headers: { "content-type": "application/json" }
      },
      (res) => {
        let body = "";
        res.on("data", (chunk) => {
          body += chunk;
        });
        res.on("end", () => {
          try {
            const result = JSON.parse(body);
            if (res.statusCode !== 200)
              reject(new Error(result.error ?? "Portal operation failed"));
            else resolve(result);
          } catch (error) {
            reject(error);
          }
        });
      }
    );
    req.setTimeout(
      45e3,
      () => req.destroy(
        new Error("Portal operation timed out; check status before retrying")
      )
    );
    req.on("error", reject);
    req.end(JSON.stringify(input));
  });
}

// plugin.js
var description = "Private homelab previews: start, expose, inspect and stop thread-owned web servers with free HTTPS portal links.";
function plugin_default(amp) {
  amp.registerTool({
    name: "raygen_portal",
    title: "Homelab portal",
    description: "Create and manage private HTTPS previews on the homelab runner. Use start with an absolute cwd and a foreground command listening on $PORT; $PUBLIC_URL and the exact Vite allowed host are supplied. Use expose for an existing loopback HTTP server. Actions: start, expose, list, status, logs, restart, stop, login-url. Names are scoped to this Amp thread. Identical start/expose renews a 24-hour lease and reuses the URL; changed definitions require stop/start. Check ready before sharing. Previews use the shared PIN by default; optional pin on start/expose overrides it for that portal. PINs are secrets; do not put them in URLs, commands or logs. Give people the ordinary url (built-in PIN screen); login-url is a sensitive single-use 60-second URL only for curl/headless browsers\u2014never share it publicly. Portals are private; this does not enable Amp\u2019s native Portal tab, annotations, or multiplayer. Do not use this to expose admin services or arbitrary LAN hosts.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        action: {
          type: "string",
          enum: [
            "start",
            "expose",
            "list",
            "status",
            "logs",
            "restart",
            "stop",
            "login-url"
          ]
        },
        name: {
          type: "string",
          pattern: "^[a-z0-9][a-z0-9-]{0,31}$",
          description: "Required except for list; stable name within this thread."
        },
        cwd: {
          type: "string",
          description: "Absolute workspace directory, required for start."
        },
        command: {
          type: "string",
          description: "Foreground shell command, required for start. Listen on $PORT; do not background it."
        },
        port: {
          type: "integer",
          minimum: 1024,
          maximum: 65535,
          description: "Required for expose; optional fixed port for start."
        },
        pin: {
          type: "string",
          pattern: "^[0-9]{8,12}$",
          description: "Optional secret PIN for start/expose, replacing the shared PIN on this portal. Use a random 8\u201312 digit string. Omit to use the shared PIN on new portals or preserve an existing portal's PIN."
        }
      },
      required: ["action"]
    },
    async execute(input, ctx) {
      return JSON.stringify(
        await callPortal({ ...input, thread: ctx.thread.id }),
        null,
        2
      );
    }
  });
}
export {
  plugin_default as default,
  description
};
